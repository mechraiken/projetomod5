export class Profiles{
    title         :String[100];
    imageURL      :String[255];
    userId?       :number;
  }